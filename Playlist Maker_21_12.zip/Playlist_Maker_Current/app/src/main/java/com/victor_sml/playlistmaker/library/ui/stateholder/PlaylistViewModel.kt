package com.victor_sml.playlistmaker.library.ui.stateholder

import androidx.lifecycle.ViewModel

class PlaylistViewModel: ViewModel()