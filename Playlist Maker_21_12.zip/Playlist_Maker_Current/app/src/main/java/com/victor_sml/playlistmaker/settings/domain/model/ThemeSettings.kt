package com.victor_sml.playlistmaker.settings.domain.model

data class ThemeSettings(val isDarkTheme: Boolean)