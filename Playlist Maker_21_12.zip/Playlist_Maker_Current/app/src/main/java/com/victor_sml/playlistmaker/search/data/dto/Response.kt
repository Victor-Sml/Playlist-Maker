package com.victor_sml.playlistmaker.search.data.dto

open class Response {
    var resultCode = 0
}