package com.victor_sml.playlistmaker.common.data.api

interface StringSource {
    fun getString(id: String): String
}