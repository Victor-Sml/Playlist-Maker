package com.victor_sml.playlistmaker.common

object Constants {
    const val TRACK_FOR_PLAYER = "track_for_player"

    const val CLICK_DEBOUNCE_DELAY = 1000L

    const val UI_BOTTOM_SPACE_DP = 24
}