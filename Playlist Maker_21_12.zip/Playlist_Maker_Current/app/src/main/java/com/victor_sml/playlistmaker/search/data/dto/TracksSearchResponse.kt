package com.victor_sml.playlistmaker.search.data.dto

class TracksSearchResponse(val results: ArrayList<TrackDto>) : Response()