package com.victor_sml.playlistmaker.search.data.dto

data class TracksSearchRequest(val expression: String)