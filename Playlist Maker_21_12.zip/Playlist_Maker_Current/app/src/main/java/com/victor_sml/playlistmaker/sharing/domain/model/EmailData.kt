package com.victor_sml.playlistmaker.sharing.domain.model

data class EmailData(
    val emailUri: String,
    val subject: String,
    val body: String
)
