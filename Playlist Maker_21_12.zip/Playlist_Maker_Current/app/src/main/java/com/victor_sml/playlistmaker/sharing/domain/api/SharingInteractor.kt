package com.victor_sml.playlistmaker.sharing.domain.api

interface SharingInteractor {
    fun shareApp()
    fun openTerms()
    fun openSupport()
}