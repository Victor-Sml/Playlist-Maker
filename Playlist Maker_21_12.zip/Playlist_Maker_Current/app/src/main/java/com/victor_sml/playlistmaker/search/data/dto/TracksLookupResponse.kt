package com.victor_sml.playlistmaker.search.data.dto

class TracksLookupResponse(val results: ArrayList<TrackDto>) : Response()